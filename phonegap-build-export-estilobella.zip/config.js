define( function ( require ) {

	"use strict";

	return {
		app_slug : 'estilobella',
		wp_ws_url : 'http://estilobella.com.br/wp-appkit-api/estilobella',
		wp_url : 'http://estilobella.com.br',
		theme : 'q-android',
		version : '1001',
		app_type : 'phonegap-build',
		app_title : '',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : 'q~V_/c{cIy4kdn84}i43:#$*Xz7wX/XD efT=[>(S<MJp4Jk>eit7j,n*SS<]Y*=',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
